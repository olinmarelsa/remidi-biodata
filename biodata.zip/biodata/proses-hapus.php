<?php
include 'koneksi.php';
if(isset($_GET['ids'])) {
    $delete = mysqli_query($conn, "DELETE FROM biodata_siswa WHERE id = '".$_GET['ids']."' ");
    echo '<script>window.location="siswa.php"</script>';
}

if(isset($_GET['idk'])) {
    $delete = mysqli_query($conn, "DELETE FROM biodata_kelas WHERE id = '".$_GET['idk']."' ");
    echo '<script>window.location="kelas.php"</script>';
}
if(isset($_GET['ida'])) {
    $delete = mysqli_query($conn, "DELETE FROM biodata_agama WHERE id = '".$_GET['ida']."' ");
    echo '<script>window.location="agama.php"</script>';
}
?>