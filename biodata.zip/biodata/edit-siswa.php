<?php
    session_start();
    include 'koneksi.php';
    $siswa = mysqli_query($conn, " SELECT * FROM biodata_siswa WHERE id = '".$_GET['id']."' ");
    $s = mysqli_fetch_object($siswa);
?>    
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Biodata</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
    <!-- header -->
    <header>
            <div class="container">
                 <h1><a href="dashboard.php">Biodata</a></h1>
                <ul>
                    <li><a href="dashboard.php">Dashboard</a></li>
                    <li><a href="siswa.php">Biodata Siswa</a></li>
                    <li><a href="agama.php">Agama</a></li>
                    <li><a href="Kelas.php">Kelas</a></li>
                    <li><a href="keluar.php">Keluar</a></li>
</ul>    
        </div>
</header>
<!-- content -->
<div class="section">
    <div class="container">
        <h3>Edit Data Siswa</h3>
        <div class="box">
            <form action="" method="POST" enctype="multipart/form-data">
                
                </select>
                    <input type="text" name="nama" class="input-control"placeholder="Nama" value="<?php echo $s->nama ?>" required>
                    <input type="text" name="tplahir" class="input-control" placeholder="Tempat Lahir" value="<?php echo $s->tplahir ?>" required>
                    <input type="date" name="tglahir" class="input-control" placeholder="Tanggal Lahir"value="<?php echo $s->tglahir ?>" required>
                    <input type="text" name="alamat" class="input-control" placeholder="Alamat"value="<?php echo $s->alamat ?>"  required>
                    <input type="text" name="hobi" class="input-control" placeholder="Hobi" value="<?php echo $s->hobi ?>" required>
                    <input type="text" name="cita_cita" class="input-control" placeholder="Cita - Cita" value="<?php echo $s->cita_cita?>" required>
                    <input type="text" name="jm_saudara" class="input-control" placeholder="Jumlah Saudara" value="<?php echo $s->jm_saudara ?>" required>
                    <input type="text" name="idkelas" class="input-control" placeholder="Kelas" value="<?php echo $s->idkelas ?>" required>                   
                    <input type="text" name="idagama" class="input-control" placeholder="Agama" value="<?php echo $s->idagama ?>" required>
                    <input type="submit" name="submit" value="Submit" class="btn">
</form>
<?php 
            if(isset($_POST['submit'])) {
                $nama    = $_POST['nama'];
                $tplahir        = $_POST['tplahir'];
                $tglahir      = $_POST['tglahir'];
                $alamat   = $_POST['alamat'];
                $hobi      = $_POST['hobi'];
                $cita_cita      = $_POST['cita_cita'];
                $jm_saudara      = $_POST['jm_saudara'];
                $idkelas     = $_POST['idkelas'];
                $idagama      = $_POST['idagama'];

                $update = mysqli_query($conn, "UPDATE biodata_siswa SET
                    nama = '".$nama."',
                    tplahir ='".$tplahir."', 
                    tglahir ='".$tglahir."',
                    alamat = '".$alamat."',
                    hobi = '".$hobi."',
                    cita_cita = '".$cita_cita."',
                    jm_saudara = '".$jm_saudara."',
                    idkelas= '".$idkelas."',
                    idagama = '".$idagama."'
                    WHERE id = '".$s->id."' ");
        if($update){
            echo '<script>alert("Ubah data berhasil")</script>';
            echo '<script>window.location="siswa.php"</script>';
 }else{
            echo 'gagal'.mysqli_error($conn);
        }

    }
                             
?>
</div>
    </div>
</div>
</body>
</html>
